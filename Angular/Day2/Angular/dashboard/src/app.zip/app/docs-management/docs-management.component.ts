import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-docs-management',
  templateUrl: './docs-management.component.html',
  styleUrls: ['./docs-management.component.scss']
})
export class DocsManagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
